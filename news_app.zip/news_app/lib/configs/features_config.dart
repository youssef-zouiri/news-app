/* App Specific Features
  true = Enabled
  false = Disabled
*/

// Multi-language
const bool isMultilanguageEnbled = true;

// Facebook Login
const bool isFacebookLoginEnabled = false;

// Google Login
const bool isGoogleLoginEnabled = true;

// Phone Number Login
const bool isPhoneNumberLoginEnabled = false;

// Apple Login
const bool isAppleLoginEnabled = true;

// Splash Icon Animations
const bool splashIconAnimationEnabled = false;



