package com.zouiri.news

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity()
